import sys
import re
import urllib.parse
import requests
import xbmcgui
import xbmcplugin

# -------------------------------------------------------------
# 
URL_M3U = "https://raw.githubusercontent.com/carlhenriyxcom-ctv/XCC-PLAY-/refs/heads/main/XCCBrxcc.m3u"
# -------------------------------------------------------------

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

def get_m3u_data():
    """Baixa o arquivo M3U da nuvem."""
    try:
        response = requests.get(URL_M3U, timeout=10)
        response.encoding = 'utf-8'
        return response.text
    except Exception:
        return ""

def parse_m3u(content):
    """Extrai titulo, capa, categoria e link do stream M3U com suporte a logos."""
    items = []
    pattern = r'#EXTINF:-1\s*(?:([^\n]*?)[\s]*),([^\n]+)\n(http[s]?://[^\s]+)'
    matches = re.findall(pattern, content)

    for extinf_data, title, url in matches:
        logo_match = re.search(r'tvg-logo="([^"]*)"', extinf_data)
        logo = logo_match.group(1) if logo_match else ''

        group_match = re.search(r'group-title="([^"]*)"', extinf_data)
        group = group_match.group(1) if group_match else 'Outros'

        items.append({
            'title': title.strip(),
            'logo': logo.strip(),
            'group': group.strip(),
            'url': url.strip()
        })
    return items

def show_categories(items):
    """Cria os menus de categorias com base no group-title da M3U."""
    categories = sorted(list(set(item['group'] for item in items)))
    
    for cat in categories:
        list_item = xbmcgui.ListItem(label=cat)
        url = f"{BASE_URL}?action=show_group&group={urllib.parse.quote(cat)}"
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)
        
    xbmcplugin.endOfDirectory(HANDLE)

def show_group_items(items, target_group):
    """Lista os filmes da categoria selecionada aplicando as capas."""
    for item in items:
        if item['group'] == target_group:
            list_item = xbmcgui.ListItem(label=item['title'])
            
            if item['logo']:
                list_item.setArt({'thumb': item['logo'], 'icon': item['logo'], 'poster': item['logo']})
                
            list_item.setInfo('video', {'title': item['title']})
            list_item.setProperty('IsPlayable', 'true')
            
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=item['url'], listitem=list_item, isFolder=False)
            
    xbmcplugin.endOfDirectory(HANDLE)

def main():
    try:
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    except IndexError:
        params = {}
        
    action = params.get('action')
    
    m3u_content = get_m3u_data()
    items = parse_m3u(m3u_content)

    if not action:
        show_categories(items)
    elif action == 'show_group':
        group_name = urllib.parse.unquote(params.get('group', ''))
        show_group_items(items, group_name)

if __name__ == '__main__':
    main()
